# Huron overlay charts

Double-click Huron_OverlayCharts.exe and press Enter to read huron_with_average.csv beside it.
Creates bilingual, English, and French 300-DPI PNG charts beside the CSV and
opens them with your default image viewer. Existing PNGs with matching names
are replaced. Requires Windows and .NET Framework 4.8; no Python required.

English title: Lake Huron Ice Cover
French title: Couverture de glace du lac Huron

Command-line options:
  Huron_OverlayCharts.exe [CSV] [--output-dir FOLDER] [--last-n 5] [--no-show]

Run build.ps1 in PowerShell to rebuild from OverlayCharts.cs.

