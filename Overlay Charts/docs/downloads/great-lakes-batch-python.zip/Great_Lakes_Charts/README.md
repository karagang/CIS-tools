# Great Lakes ice-cover charts

This package combines the two supplied plotting scripts into one program. It
includes copies of all six supplied CSVs in `Data` and 12 generated charts in
`output`. Original source files are unchanged.

## Run

Install Python 3.9 or newer, then open a terminal in this folder and run:

```powershell
python -m pip install -r requirements.txt
python great_lakes_charts.py
```

No file prompts or chart windows appear. The program creates both a single-season
chart and a two-season chart for each lake, automatically creating this structure:

```text
Great_Lakes_Charts/
  great_lakes_charts.py
  requirements.txt
  Data/
    eri_with_avg.csv
    ont_with_avg.csv
    mic_with_avg.csv
    hur_with_avg.csv
    sup_with_avg.csv
    grtlks_with_avg.csv
  output/
    Lake Erie/
    Lake Ontario/
    Lake Michigan/
    Lake Huron/
    Lake Superior/
    Great Lakes/
```

Each output subfolder contains `single_season_2025.png` and
`two_seasons_2024_2025.png` for the supplied data. The program chooses the latest
year with nonblank observations inside the chart's date range independently for
each lake. It compares that year with the preceding calendar year and uses the
existing `Average` column. Year labels follow the original CSVs. Add newer year
columns to the CSVs and the program will select them automatically.

Charts retain the bilingual titles, blue latest season, red preceding season,
lime historical average, and November 1–June 21 date axis. February 29 is supported.
Blank observations remain gaps. The program validates all six inputs before
plotting and reports missing files, missing season data, or invalid values.

The defaults are relative to the program's location, so it can be launched from
another working directory. You can override them:

```powershell
python great_lakes_charts.py --data-dir "C:\path\to\Data" --output-dir "C:\path\to\output"
python great_lakes_charts.py --year 2025
```

The filenames `ontr_with_avg.csv` and `supr_with_avg.csv` are also accepted for
Ontario and Superior. Replace the CSV copies in `Data` when your data changes.
Rerunning overwrites charts with the same names; charts for older year selections
remain in place.
