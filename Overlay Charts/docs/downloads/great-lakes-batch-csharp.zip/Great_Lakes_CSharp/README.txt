GREAT LAKES ICE-COVER CHARTS — C# WINDOWS EXECUTABLE

RUN
1. Extract the entire ZIP to a writable folder.
2. Double-click GreatLakesCharts.exe.
3. A completion message shows where the 12 charts were saved.

No Python, pip, or charting package installation is needed. This Windows
application uses Microsoft .NET Framework 4.x. Keep the Data folder beside
the executable. The included CSVs are copies of your six original files.

OUTPUT
output\Lake Erie\
output\Lake Ontario\
output\Lake Michigan\
output\Lake Huron\
output\Lake Superior\
output\Great Lakes\

Each folder receives single_season_2025.png and two_seasons_2024_2025.png
with the supplied data. Each PNG is 2400 x 1200 pixels at 200 DPI.
The package also includes the 12 charts generated during testing.

The program selects the latest populated year separately for each CSV, compares
it with the preceding calendar year, and plots the supplied Average column.
Year labels follow the CSVs. Replace the Data CSVs when new data is available.
Ontario accepts ont_with_avg.csv or ontr_with_avg.csv; Superior accepts
sup_with_avg.csv or supr_with_avg.csv. All other filenames match the Python
package. Headers must include Date, Average, and four-digit year columns.

Bilingual titles, the Nov 1–Jun 21 axis, daily ticks, blue latest season,
red previous season, and lime historical average match the Python version.
The C# charts are drawn with Windows graphics: fonts, tick spacing on the
vertical axis, and margins can differ slightly from Matplotlib output.
February 29 is supported and missing values remain gaps. All six inputs are
validated before rendering. Invalid inputs produce an error dialog.

Rerunning replaces charts with identical names. Older season charts remain.
Defaults are relative to the executable, regardless of the working directory.

OPTIONAL COMMAND-LINE ARGUMENTS (PowerShell)
  .\GreatLakesCharts.exe --data-dir 'C:\path\Data' --output-dir 'C:\path\output'
  .\GreatLakesCharts.exe --year 2025
  .\GreatLakesCharts.exe --quiet
  .\GreatLakesCharts.exe --help

--quiet suppresses dialogs for batch execution. Exit code 0 means success;
1 means failure. When invoked with redirected output, status goes to stdout
and errors to stderr. For synchronous command-line execution in PowerShell:
  $p = Start-Process .\GreatLakesCharts.exe -ArgumentList '--quiet' -Wait -PassThru -WindowStyle Hidden
  $p.ExitCode

SOURCE AND REBUILD
Source\GreatLakesCharts.cs contains the complete C# source code.
Source\build.ps1 rebuilds the executable with the Windows .NET Framework
compiler, using only framework assemblies and no NuGet dependencies:
  powershell -NoProfile -ExecutionPolicy Bypass -File .\Source\build.ps1

Implementation references:
https://learn.microsoft.com/en-us/dotnet/api/system.drawing.graphics
https://learn.microsoft.com/en-us/dotnet/api/microsoft.visualbasic.fileio.textfieldparser
