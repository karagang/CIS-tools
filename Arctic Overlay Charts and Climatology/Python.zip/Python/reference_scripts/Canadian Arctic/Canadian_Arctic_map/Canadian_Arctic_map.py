import matplotlib.pyplot as plt
import cartopy.crs as ccrs
from shapely.geometry import Polygon
import cartopy.feature as cfeature

# Polygon coordinates
coords = [
    (-162.05916768573772, 70.15453830737627),
    (-165.46350043443024, 70.61138122556594),
    (-158.57295918362897, 73.33623508320517),
    (-150.31414659638864, 72.73793040646794),
    (-95.02403516385291, 81.3658935599311),
    (-70.67564481585896, 81.56913918219402),
    (-59.98751067350253, 81.93779555099613),
    (-64.5923313002341, 76.35853875171867),
    (-58.96395508074556, 76.38181347947477),
    (-50.46201334627176, 71.36632573824346),
    (-49.7872569921511, 70.36850173104943),
    (-54.77840400835866, 68.8381994525194),
    (-55.15449821102814, 66.63986389637577),
    (-54.74952560219229, 61.33367101810845),
    (-64.2506197235275, 60.32773981069073),
    (-68.07868751784753, 62.47482501662418),
    (-73.71835035048183, 64.80260004419063),
    (-77.54154808659798, 64.4609288821911),
    (-82.8441313586269, 64.63295195261193),
    (-85.73544344526199, 64.73625140706557),
    (-89.15671514529657, 64.96156420364846),
    (-93.70660783877076, 66.31341253637092),
    (-94.44463875184294, 67.03526027633822),
    (-98.18225103024531, 66.86472486329379),
    (-100.78840899812079, 67.20462509861437),
    (-105.7744102952538, 67.41705352098757),
    (-106.58136773528523, 66.45665062842801),
    (-112.12945010449249, 66.66204537075598),
    (-116.75369973719705, 67.53602949342263),
    (-127.30839285508955, 68.63906512076736),
    (-135.34635216898798, 67.0085001487239),
    (-160.82908730941855, 70.07479556958174),
    (-162.05916768573772, 70.15453830737627),   # CLOSE the polygon by copying first point at the end!!!
]

polygon = Polygon(coords)

# Set up the figure and axes
fig = plt.figure(figsize=(12, 10))
ax = plt.axes(projection=ccrs.LambertConformal(
    central_longitude=-100, central_latitude=65,
    standard_parallels=(55, 75)))
ax.set_extent([-170, -50, 51, 83], crs=ccrs.PlateCarree())
ax.add_feature(cfeature.BORDERS, linewidth=1, edgecolor='black')
ax.add_feature(cfeature.COASTLINE, linewidth=0.5)
ax.add_feature(cfeature.LAND, facecolor='lightgray')

# Add the polygon
ax.add_geometries([polygon], ccrs.PlateCarree(),
                  facecolor='red', edgecolor='darkred', alpha=0.5)

ax.set_title('Canadian Arctic')
plt.tight_layout()
plt.savefig('Canadian_Arctic_highlighted.png', dpi=300)
plt.show()
