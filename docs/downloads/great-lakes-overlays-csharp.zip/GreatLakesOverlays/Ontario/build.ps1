$ErrorActionPreference = 'Stop'
$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (-not (Test-Path -LiteralPath $compiler)) {
    $compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe'
}
if (-not (Test-Path -LiteralPath $compiler)) { throw 'Install .NET Framework 4.8 to build this program.' }
$framework = Split-Path $compiler
& $compiler /nologo /target:exe /optimize+ /codepage:65001 "/out:$PSScriptRoot\Ontario_OverlayCharts.exe" /reference:System.Drawing.dll /reference:System.Windows.Forms.dll /reference:System.Windows.Forms.DataVisualization.dll "/reference:$framework\Microsoft.VisualBasic.dll" "$PSScriptRoot\OverlayCharts.cs"
if ($LASTEXITCODE -ne 0) { throw 'C# compilation failed.' }
Write-Host "Built $PSScriptRoot\Ontario_OverlayCharts.exe"


