# Great Lakes overlay charts — C#

Windows application using .NET Framework 4.x libraries:

- `System.Windows.Forms.DataVisualization.Charting` renders the charts.
- `System.Drawing` exports 3600 × 1800 PNGs at 300 DPI.
- `Microsoft.VisualBasic.FileIO.TextFieldParser` reads quoted CSV fields from C#.

No Python, Python libraries, or NuGet packages are needed. Requires Windows and
.NET Framework 4.8. The executable was built and run against the supplied CSV.

## Run

Double-click `OverlayCharts.exe`, paste the CSV path at the prompt, and press Enter.
If `bas_with_average.csv` is beside the executable, press Enter to use it.
The three saved PNGs open in your default image viewer.

From PowerShell, in this directory:

```powershell
.\OverlayCharts.exe 'D:\path\to\bas_with_average.csv'
.\OverlayCharts.exe 'D:\path\to\bas_with_average.csv' --output-dir '.\charts' --no-show
.\OverlayCharts.exe --help
```

Output defaults to the CSV directory. Files with the following names are replaced
when rerunning with the same CSV and output directory:

- `bas_with_average_chart_BILINGUAL.png`
- `bas_with_average_chart_EN.png`
- `bas_with_average_chart_FR.png`

`--last-n 5` highlights the latest five calendar years, matching the Python
program. Older years are faint gray, recent years are tinted, the latest year
uses its full color, and the supplied Average column is lime green. The average
is read directly from the CSV, not recomputed.

Input requires Date, Average, and numeric year columns. Dates may use `14-Nov`
or `Nov-14`. A November–June seasonal axis preserves February 29. Missing values
such as empty fields and NA are omitted, connecting the remaining points as in
the Python program. English dates are used for the bilingual chart; the French
chart uses French month abbreviations. Rendering and automatic Y-axis ticks
differ slightly from Matplotlib.

## Build from source

Run `build.ps1` from PowerShell:

```powershell
.\build.ps1
```

The script locates the Windows .NET Framework C# compiler and builds
`OverlayCharts.exe` from `OverlayCharts.cs`. It does not download dependencies.

The `charts` directory contains sample output generated from the supplied CSV.
