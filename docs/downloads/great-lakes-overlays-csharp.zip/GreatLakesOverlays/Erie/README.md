# Erie overlay charts

Double-click Erie_OverlayCharts.exe and press Enter to read erie_with_average.csv beside it.
Creates bilingual, English, and French 300-DPI PNG charts beside the CSV and
opens them with your default image viewer. Existing PNGs with matching names
are replaced. Requires Windows and .NET Framework 4.8; no Python required.

English title: Lake Erie Ice Cover
French title: Couverture de glace du lac Érié

Command-line options:
  Erie_OverlayCharts.exe [CSV] [--output-dir FOLDER] [--last-n 5] [--no-show]

Run build.ps1 in PowerShell to rebuild from OverlayCharts.cs.

