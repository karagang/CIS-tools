$ErrorActionPreference = 'Stop'
$packageDir = Split-Path -Parent $PSScriptRoot
$framework = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319'
if (-not (Test-Path -LiteralPath (Join-Path $framework 'csc.exe'))) {
    $framework = Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319'
}
$compiler = Join-Path $framework 'csc.exe'
if (-not (Test-Path -LiteralPath $compiler)) { throw 'The .NET Framework C# compiler was not found.' }
& $compiler /nologo /target:winexe /platform:anycpu /optimize+ /codepage:65001 "/out:$packageDir\GreatLakesCharts.exe" "/reference:$framework\System.Drawing.dll" "/reference:$framework\System.Windows.Forms.dll" "/reference:$framework\Microsoft.VisualBasic.dll" (Join-Path $PSScriptRoot 'GreatLakesCharts.cs')
if ($LASTEXITCODE -ne 0) { throw 'Compilation failed.' }
Write-Output "Built $packageDir\GreatLakesCharts.exe"
